<?php

use Magento\Framework\App\Bootstrap;
use Mirasvit\Helpdesk\Model\Config;


require __DIR__ . '/app/bootstrap.php';

$nl = '<br>';
if (php_sapi_name() == 'cli') {
    $nl = PHP_EOL;
}

/**
 * Helper function to convert XML Node to array
 *
 * @param Varien_Object $xmlNode
 * @return array
 */
// @codingStandardsIgnoreStart
function xmlToArray($xmlNode)
{
    $result = [];

    $subnodes = $xmlNode->childNodes;
    for ($i = 0; $i < $subnodes->length; $i++) {
        $attr = $subnodes->item($i);
        if(get_class($attr) == 'DOMElement') {
            $result[$attr->tagName] = $attr->nodeValue;
        }
    }
    unset($result['']); // We need it to skip empty #TEXT section of parent node

    return $result;
}

function getStore($data)
{
    $obj = \Magento\Framework\App\ObjectManager::getInstance();
    /** @var \Magento\Store\Model\StoreManagerInterface $storeManager */
    $storeManager = $obj->create('Magento\Store\Model\StoreManagerInterface');
    $stores = $storeManager->getStores();
    $allStores = [];
    $storeIds = [];
    foreach ($stores as $store) {
        $allStores[] = $store->getId();
    }
    $storeCodes = json_decode(base64_decode($data['store_codes']));
    foreach ((array)$storeCodes as $code) {
        /** @var \Magento\Store\Model\StoreManagerInterface $storeManager */
        $storeManager = $obj->create('Magento\Store\Model\StoreManagerInterface');
        try {
            $store = $storeManager->getStore($code);
        } catch (\Exception $e) {
            echo  $e->getMessage();
            continue;
        }
        if ($store->getId() !== null) {
            if ((int)$store->getId() === 0) {
                $storeIds = $allStores;
            } else {
                $storeIds[] = $store->getId();
            }
        }
    }

    return $storeIds;
}
// @codingStandardsIgnoreEnd

$bootstrap = Bootstrap::create(BP, $_SERVER);
$obj = $bootstrap->getObjectManager();

// Set the state to backend, as we're uploading data
$state = $obj->get('Magento\Framework\App\State');
$state->setAreaCode('adminhtml');

echo '<h1>Import migration HDMX data from M1 to M2</h1>' . $nl;

/** @var \Mirasvit\Helpdesk\Model\Config $configModel */
$configModel = $obj->create('Mirasvit\Helpdesk\Model\Config');
$sandboxMode = $configModel->getDeveloperIsActive();

/** @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface $config */
$config = $obj->create('Magento\Framework\App\Config\ConfigResource\ConfigInterface');
$config->saveConfig(
    'helpdesk/developer/is_active',
    1,
    \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
    \Magento\Store\Model\Store::DEFAULT_STORE_ID
);

$exportFile = 'helpdesk_export.xml';

// Hashes for dictionary values
$departmentHash = [];
$gatewayHash = [];
$statusHash = [];
$priorityHash = [];

$xmlParser = new \Magento\Framework\Xml\Parser();
$xmlParser->initErrorHandler();

try {
    $document = $xmlParser->load($exportFile)->getDom();
    $root = $document->getElementsByTagName('HDMX')->item(0);

    // Stage 0: Load dictionaries
    $dictionaries = $root->getElementsByTagName('Dictionaries')->item(0);

    // 0.1. Departments
    $departments = $dictionaries->getElementsByTagName('Departments')->item(0)->getElementsByTagName('Department');
    echo "Loading departments: " . $nl;
    for ($i = 0; $i < $departments->length; $i++) {
        $data = xmlToArray($departments->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Department\CollectionFactory');
        /** @var \Mirasvit\Helpdesk\Model\ResourceModel\Department\Collection $collection */
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['department_id'];
            unset($data['department_id']);
            $userIds = [];
            $userNames = json_decode(base64_decode($data['user_names']));
            foreach ((array)$userNames as $name) {
                /** @var \Magento\User\Model\UserFactory $userFactory */
                $userFactory = $obj->create('Magento\User\Model\UserFactory')->create();
                $user = $userFactory->loadByUsername($name);
                if ($user->getId() !== null) {
                    $userIds[] = $user->getId();
                }
            }
            $storeIds = getStore($data);
            unset($data['user_emails']);
            unset($data['store_codes']);
            if ($userIds) {
                $data['user_ids'] = $userIds;
            }
            if ($storeIds) {
                $data['store_ids'] = $storeIds;
            }
            $department = $obj->create('Mirasvit\Helpdesk\Model\Department');
            $department->setData($data);
            $department->setData('name', $data['name']);
            $department->save();
            $departmentHash[$oldId] = $department->getId();
            echo ' - department ' . $department->getName() . ' created' . $nl;
        } else {
            $department = $collection->getFirstItem();
            $departmentHash[$data['department_id']] = $department->getId();
            echo ' - department ' . $department->getName() . ' loaded ' . $nl;
        }
    }

    // 0.2. Gateways
    $gateways = $dictionaries->getElementsByTagName('Gateways')->item(0)->getElementsByTagName('Gateway');
    echo "Loading gateways: " . $nl;
    for ($i = 0; $i < $gateways->length; $i++) {
        $data = xmlToArray($gateways->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Gateway\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['gateway_id'];
            unset($data['gateway_id']);
            $gate = $obj->create('Mirasvit\Helpdesk\Model\Gateway');
            $gate->setData($data);
            $gate->setData('folder', $data['mail_folder']);
            $gate->setData('department_id', $departmentHash[$data['department_id']]);
            $gate->save();
            $gatewayHash[$oldId] = $gate->getId();
            echo ' - gateway ' . $gate->getName() . ' created' . $nl;
        } else {
            $gate = $collection->getFirstItem();
            $gatewayHash[$data['gateway_id']] = $gate->getId();
            echo ' - gateway ' . $gate->getName() . ' loaded ' . $nl;
        }
    }

    // 0.3. Statuses
    $statuses = $dictionaries->getElementsByTagName('Statuses')->item(0)->getElementsByTagName('Status');
    echo "Loading statuses: " . $nl;
    for ($i = 0; $i < $statuses->length; $i++) {
        $data = xmlToArray($statuses->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Status\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('code', $data['code'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['status_id'];
            $storeIds = getStore($data);
            if ($storeIds) {
                $data['store_ids'] = $storeIds;
            }

            unset($data['status_id']);
            unset($data['store_codes']);

            $status = $obj->create('Mirasvit\Helpdesk\Model\Status');
            $status->setData($data);
            $status->save();
            $statusHash[$oldId] = $status->getId();
            echo ' - status ' . $status->getName() . ' created' . $nl;
        } else {
            $status = $collection->getFirstItem();
            $statusHash[$data['status_id']] = $status->getId();
            echo ' - status ' . $status->getName() . ' loaded ' . $nl;
        }
    }

    // 0.3. Priorities
    $priorities = $dictionaries->getElementsByTagName('Priorities')->item(0)->getElementsByTagName('Priority');
    echo "Loading priorities: " . $nl;
    for ($i = 0; $i < $priorities->length; $i++) {
        $data = xmlToArray($priorities->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Priority\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['priority_id'];
            $storeIds = getStore($data);
            if ($storeIds) {
                $data['store_ids'] = $storeIds;
            }

            unset($data['store_codes']);
            unset($data['priority_id']);
            $priority = $obj->create('Mirasvit\Helpdesk\Model\Priority');
            $priority->setData($data);
            $priority->save();
            $priorityHash[$oldId] = $priority->getId();
            echo ' - status ' . $priority->getName() . ' created' . $nl;
        } else {
            $priority = $collection->getFirstItem();
            $priorityHash[$data['priority_id']] = $priority->getId();
            echo ' - status ' . $priority->getName() . ' loaded ' . $nl;
        }
    }

    // 0.6. Quick Responses
    $responses = $dictionaries->getElementsByTagName('Responses')->item(0)->getElementsByTagName('Response');
    echo "Loading Quick Responses: " . $nl;
    for ($i = 0; $i < $responses->length; $i++) {
        $data = xmlToArray($responses->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Template\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['template_id'];
            $storeIds = getStore($data);
            if ($storeIds) {
                $data['store_ids'] = $storeIds;
            }

            unset($data['store_codes']);
            unset($data['template_id']);
            $response = $obj->create('Mirasvit\Helpdesk\Model\Template');
            $response->setData($data);
            $response->save();
            $responseHash[$oldId] = $response->getId();
            echo ' - quick response ' . $response->getName() . ' created' . $nl;
        } else {
            $response = $collection->getFirstItem();
            echo ' - quick response ' . $response->getName() . ' already loaded ' . $nl;
        }
    }

    // 0.6. Third Party Emails skipped - M2 currently do not support it

    // 0.7. Custom Fields
    $fields = $dictionaries->getElementsByTagName('Fields')->item(0)->getElementsByTagName('Field');
    echo "Loading Custom Fields: " . $nl;
    for ($i = 0; $i < $fields->length; $i++) {
        $data = xmlToArray($fields->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Field\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['field_id'];
            $storeIds = getStore($data);
            if ($storeIds) {
                $data['store_ids'] = $storeIds;
            }

            unset($data['store_codes']);
            unset($data['field_id']);
            $field = $obj->create('Mirasvit\Helpdesk\Model\Field');
            $field->setData($data);
            $field->setData('code', substr($data['code'], 2));
            $field->save();
            echo ' - custom field ' . $field->getName() . ' created' . $nl;
        } else {
            $field = $collection->getFirstItem();
            echo ' - custom field ' . $field->getName() . ' already loaded ' . $nl;
        }
    }

    // 0.8. Spam Patterns
    $patterns = $dictionaries->getElementsByTagName('SpamPatterns')->item(0)->getElementsByTagName('Pattern');
    echo "Loading Spam Patterns: " . $nl;
    for ($i = 0; $i < $patterns->length; $i++) {
        $data = xmlToArray($patterns->item($i));

        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Pattern\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $data['name'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['pattern_id'];
            unset($data['pattern_id']);
            $pattern = $obj->create('Mirasvit\Helpdesk\Model\Pattern');
            $pattern->setData($data);
            $pattern->save();
            echo ' - spam pattern ' . $pattern->getName() . ' created' . $nl;
        } else {
            $pattern = $collection->getFirstItem();
            echo ' - spam pattern ' . $pattern->getName() . ' already loaded ' . $nl;
        }
    }

    // 0.9. Permissions dictionary skipped due to incompatibility

    // Stage 1. Tickets uploading

    $tickets = $root->getElementsByTagName('Tickets')->item(0)->getElementsByTagName('Ticket');
    echo "Loading Tickets: " . $nl;
    for ($i = 0; $i < $tickets->length; $i++) {
        $currentTicket = $tickets->item($i);
        $data = xmlToArray($currentTicket);

        echo 'Loading: ' . $data['code'] . PHP_EOL;
        $dataCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Ticket\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('code', $data['code'])
            ->load();

        if (!count($collection)) {
            $oldId = $data['ticket_id'];
            unset($data['ticket_id']);
            $ticket = $obj->create('Mirasvit\Helpdesk\Model\Ticket');
            $ticket->setData($data);
            $ticket->setData('subject', base64_decode($data['name']));
            $ticket->setData('customer_name', base64_decode($data['customer_name']));
            $ticket->setData('last_reply_name', base64_decode($data['last_reply_name']));
            if (!empty($data['f_company'])) {
                $ticket->setData('f_company', base64_decode($data['f_company']));
            }
            $ticket->setData('priority_id', $priorityHash[$data['priority_id']]);
            $ticket->setData('status_id', $statusHash[$data['status_id']]);
            if(isset($data['department_id'])) {
                $ticket->setData('department_id', isset($departmentHash[$data['department_id']]) ?
                    $departmentHash[$data['department_id']] :
                    array_values($departmentHash)[0]);
            }

            // Pick up customer by his email
            /* $customerCollection = $obj->create('Magento\Customer\Model\Customer')->getCollection()
                ->addFieldToFilter('email', $data['customer_email'])
                ->load();
            if (count($customerCollection)) {
                $ticket->setData('customer_id', $customerCollection->getFirstItem()->getId);
            }*/

            // Check store ID exists, if not, set default one
            $storeManager = $obj->get('Magento\Store\Model\StoreManagerInterface');
            try {
                $ourStore = $storeManager->getStore($data['store_id']);
            } catch (Exception $exc) {
                $ticket->setData('store_id', $storeManager->getStore()->getId());
            }

            if($data['is_spam'] == 1) {
                $ticket->setFolder(Config::FOLDER_SPAM);
            }
            if($data['is_archived'] == 1) {
                $ticket->setFolder(Config::FOLDER_ARCHIVE);
            }

            try {
                $ticket->setIsMigration(true);
                $ticket->save();
                echo ' - ticket ' . $ticket->getCode() . ' created' . $nl;
            } catch (\Exception $e) {
                echo ' - ticket ' . $ticket->getCode() . ' <span style="color: red;">failed</span>' . $nl;
            }

            $messages = $currentTicket->getElementsByTagName('Message');
            for ($j = 0; $j < $messages->length; $j++) {
                $currentMessage = $messages->item($j);
                $msgData = xmlToArray($currentMessage);
                unset($msgData['message_id']);

                $message = $obj->create('Mirasvit\Helpdesk\Model\Message');
                $message->setData($msgData);
                $message->setData('body', base64_decode($msgData['body']));
                $message->setData('customer_name', base64_decode($msgData['customer_name']));
                $message->setData('ticket_id', $ticket->getId());

                /*$customerCollection = $obj->create('Magento\Customer\Model\Customer')->getCollection()
                    ->addFieldToFilter('email', $msgData['customer_email'])
                    ->load();
                if (count($customerCollection)) {
                    $message->setData('customer_id', $customerCollection->getFirstItem()->getId);
                }*/

                $message->setIsMigration(true);
                $message->save();

            }
            echo ' - ' . $messages->length . ' message(s) added' . $nl;

        } else {
            $ticket = $collection->getFirstItem();
            echo ' - ticket ' . $ticket->getCode() . ' already loaded ' . $nl;
        }
    }


    // Stage 2: Touch uploaded data - created_at and updated_at fields

    echo $nl . "Mission accomplished" . $nl;

} catch (Exception $e) {
    echo $e->getMessage() . $nl;
}

$config->saveConfig(
    'helpdesk/developer/is_active',
    $sandboxMode,
    \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
    \Magento\Store\Model\Store::DEFAULT_STORE_ID
);

die;
