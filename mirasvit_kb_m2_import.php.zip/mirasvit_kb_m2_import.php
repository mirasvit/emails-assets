<?php
 
use Magento\Framework\App\Bootstrap;
require __DIR__ . '/app/bootstrap.php';

/**
 * Helper function to convert XML Node to array
 *
 * @param Varien_Object $xmlNode
 * @return array
 */
// @codingStandardsIgnoreStart
function xmlToArray($xmlNode)
{
    $result = [];

    $subnodes = $xmlNode->childNodes;
    for ($i = 0; $i < $subnodes->length; $i++) {
        $attr = $subnodes->item($i);
        $result[$attr->tagName] = $attr->nodeValue;
    }
    unset($result['']); // We need it to skip empty #TEXT section of parent node

    return $result;
}
// @codingStandardsIgnoreEnd

$bootstrap = Bootstrap::create(BP, $_SERVER);
$obj = $bootstrap->getObjectManager();
 
// Set the state to backend, as we're uploading data
$state = $obj->get('Magento\Framework\App\State');
$state->setAreaCode('adminhtml');

echo '<h1>Import migration Knowledge Base data from M1 to M2</h1><pre>';

$exportFile = 'kb_export.xml';

// Hashes for dictionary values
$categoryHash = [];

$xmlParser = new \Magento\Framework\Xml\Parser();
$xmlParser->initErrorHandler();

try {
    $document = $xmlParser->load($exportFile)->getDom();
    $root = $document->getElementsByTagName('KB')->item(0);

    // Stage 0: Load dictionaries
    $dictionaries = $root->getElementsByTagName('Dictionaries')->item(0);

    // 0.1. Categories
    $categories = $dictionaries->getElementsByTagName('Categories')->item(0)->getElementsByTagName('Category');
    echo "Loading categories: <br>";
    for ($i = 0; $i < $categories->length; $i++) {
        $data = xmlToArray($categories->item($i));

        $cName = base64_decode($data['name']);
        $dataCollection = $obj->create('Mirasvit\Kb\Model\ResourceModel\Category\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $cName)
            ->load()
        ;

        echo ' - category ' . $cName . '...';
        if (!count($collection)) {
            $oldId = $data['category_id'];
            unset($data['category_id']);
            $category = $obj->create('Mirasvit\Kb\Model\Category');
            $category->setData($data);
            $category->setData('name', $cName);
            $category->setData('parent_id', empty($data['parent_id']) ? 1 : $categoryHash[$data['parent_id']]);
            $category->setData('description', base64_decode($data['overview']));
            $category->setData('meta_title', base64_decode($data['meta_title']));
            $category->setData('meta_keywords', base64_decode($data['meta_keywords']));
            $category->setData('meta_description', base64_decode($data['meta_description']));
            $category->setData('store_ids', [0]);
            $category->save();
            $categoryHash[$oldId] = $category->getId();
            echo ' created<br>';
        } else {
            $category = $collection->getFirstItem();
            $categoryHash[$data['category_id']] = $category->getId();
            echo 'loaded <br>';
        }
    }

    // 0.2. Articles
    $articles = $dictionaries->getElementsByTagName('Articles')->item(0)->getElementsByTagName('Article');
    echo "Loading articles: <br>";
    for ($i = 0; $i < $articles->length; $i++) {
        $data = xmlToArray($articles->item($i));

        $aName = base64_decode($data['name']);
        $dataCollection = $obj->create('Mirasvit\Kb\Model\ResourceModel\Article\CollectionFactory');
        $collection = $dataCollection->create()
            ->addFieldToFilter('name', $aName)
            ->load();

        if (!count($collection)) {
            $oldId = $data['article_id'];
            unset($data['article_id']);
            $article = $obj->create('Mirasvit\Kb\Model\Article');
            $article->setData($data);
            $article->setData('name', $aName);
            $article->setData('text', base64_decode($data['text']));
            $article->setData('meta_title', base64_decode($data['meta_title']));
            $article->setData('meta_keywords', base64_decode($data['meta_keywords']));
            $article->setData('meta_description', base64_decode($data['meta_description']));

            // Parse category IDS
            $categoryIds = base64_decode($data['category_ids']);
            $realIds = [];
            foreach(json_decode($categoryIds) as $categoryId) {
                $realIds[] = $categoryHash[$categoryId];
            }
            $article->setData('category_ids', $realIds);

            $article->save();
            echo ' - article ' . $article->getName() . ' created<br>';
        } else {
            $article = $collection->getFirstItem();
            echo ' - article ' . $gate->getName() . ' already loaded <br>';
        }
    }

    echo "<br>Mission accomplished";

} catch (Exception $e) {
    echo $e->getMessage(); die;
}

die;
