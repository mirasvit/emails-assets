<?php
/*
 * The script has a hardcoded data for Departments and storeIds, as there is no relation of the data with freshdesk
 *         if (!empty($frTicket['to_emails']) && str_contains($frTicket['to_emails'][0], 'department@email.com')) {
            $ticket->setData('department_id', 1);
            $ticket->setData('store_id', 2);
        } else {
            $ticket->setData('department_id', 2);
            $ticket->setData('store_id', 1);
        }
 */

use Magento\Framework\App\Bootstrap;
use Mirasvit\Helpdesk\Model\Config;

require __DIR__ . '/app/bootstrap.php';

$directory = __DIR__ . "/mst_migration/";
$files     = glob($directory . "*.json");

foreach ($files as $file) {
    import($file);
}

function import($fileToImport)
{
    $nl = '<br>';
    if (php_sapi_name() == 'cli') {
        $nl = PHP_EOL;
    }

    // @codingStandardsIgnoreEnd

    $bootstrap = Bootstrap::create(BP, $_SERVER);
    $obj       = $bootstrap->getObjectManager();

    // Set the state to backend, as we're uploading data
    $state = $obj->get('Magento\Framework\App\State');
    $state->setAreaCode('adminhtml');

    echo '<h1>Import migration HDMX data freshdesk to Mirasvit HDMX</h1>' . $nl;

    /** @var \Mirasvit\Helpdesk\Model\Config $configModel */
    $configModel = $obj->create('Mirasvit\Helpdesk\Model\Config');
    $sandboxMode = $configModel->getDeveloperIsActive();

    /** @var \Magento\Framework\App\Config\ConfigResource\ConfigInterface $config */
    $config = $obj->create('Magento\Framework\App\Config\ConfigResource\ConfigInterface');
    $config->saveConfig(
        'helpdesk/developer/is_active',
        1,
        \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
        \Magento\Store\Model\Store::DEFAULT_STORE_ID
    );

    try {
        $tickets = json_decode(file_get_contents($fileToImport), true);

        //Mirasvit Statuses
        $statusCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Status\CollectionFactory')->create();
        $frStatuses       = [];
        $hdmxStatuses     = [];
        foreach ($statusCollection as $hdmxStatus) {
            $hdmxStatuses[$hdmxStatus->getCode()] = $hdmxStatus->getId();
        }

        //Mirasvit Priorities
        $priorityCollection = $obj->create('Mirasvit\Helpdesk\Model\ResourceModel\Priority\CollectionFactory')->create();
        $frPriorities       = [];
        $hdmxPriorities     = [];
        foreach ($priorityCollection as $hdmxPriority) {
            $hdmxPriorities[$hdmxPriority->getName()] = $hdmxPriority->getId();

        }

        echo "Loading Tickets: " . $nl;
        for ($i = 0; $i < count($tickets); $i++) {
            $frTicket = $tickets[$i]['helpdesk_ticket'];
            //Convert and create Status
            $frStatusName = strtolower(preg_replace('/\s+/', '_', $frTicket['status_name']));
            if (!isset($frStatuses[$frStatusName])) {
                if (!isset($hdmxStatuses[$frStatusName])) {
                    $newStatus = $obj->create('Mirasvit\Helpdesk\Model\Status');
                    $newStatus->setCode($frStatusName);
                    $newStatus->setName($frTicket['status_name']);
                    $newStatus->save();
                    $frStatuses[$frTicket['status']] = $newStatus->getId();
                } else {
                    $frStatuses[$frTicket['status']] = $hdmxStatuses[$frStatusName];
                }
            }

            //Convert and create Priorities
            $frPriorityName = trim($frTicket['priority_name']);
            if (!isset($frPriorities[$frPriorityName])) {


                if (!isset($hdmxPriorities[$frPriorityName])) {
                    $newPriority = $obj->create('Mirasvit\Helpdesk\Model\Priority');
                    $newPriority->setName($frTicket['priority_name']);
                    $newPriority->save();
                    $frPriorities[$frTicket['priority']] = $newPriority->getId();
                } else {
                    $frPriorities[$frTicket['priority']] = $hdmxPriorities[$frPriorityName];
                }
            }

            echo 'Loading: ' . $frTicket['id'] . PHP_EOL;

            $ticket = $obj->create('Mirasvit\Helpdesk\Model\Ticket');
            $ticket->setData('status_id', $frStatuses[$frTicket['status']]);
            $ticket->setData('priority_id', $frPriorities[$frTicket['priority']]);
            $ticket->setData('subject', $frTicket['subject']);
            $ticket->setData('customer_name', $frTicket['requester']['name']);
            $ticket->setData('customer_email', $frTicket['requester']['email']);
            $ticket->setData('created_at', $frTicket['created_at']);
            $ticket->setData('updated_at', $frTicket['updated_at']);
            $ticket->setData('description', $frTicket['description']);

            // The hardcoded data - should be modified --- start
            if (!empty($frTicket['to_emails']) && str_contains($frTicket['to_emails'][0], 'department@email.com')) {
                $ticket->setData('department_id', 1);
                $ticket->setData('store_id', 2);
            } else {
                $ticket->setData('department_id', 2);
                $ticket->setData('store_id', 1);
            }
            // The hardcoded data - should be modified --- end

            if ($frTicket['spam'] == 1) {
                $ticket->setFolder(Config::FOLDER_SPAM);
            }
            if ($frTicket['source_name'] == 'Email') {
                $ticket->setData('channel', 'email');
            } elseif ($frTicket['source_name'] == 'Feedback Widget') {
                $ticket->setData('channel', 'feedback_tab');
            } else {
                $ticket->setData('channel', 'backend');
            }
            if ($frTicket['ticket_states']['closed_at']) {
                $ticket->setFolder(Config::FOLDER_ARCHIVE);
            }
            if ($frTicket['cc_email']['cc_emails']) {
                $ticket->setData('cc', $frTicket['cc_email']['cc_emails'][0]);
            }

            // Pick up customer by his email
            $customerCollection = $obj->create('Magento\Customer\Model\Customer')->getCollection()
                ->addFieldToFilter('email', $frTicket['requester']['email'])
                ->load();

            if ($customerCollection->count()) {
                $ticket->setData('customer_id', $customerCollection->getFirstItem()->getId());
            }

            try {
                $ticket->setIsMigration(true);
                $ticket->save();
                echo ' - ticket ' . $ticket->getCode() . ' created' . $nl;
            } catch (\Exception $e) {
                echo ' - ticket ' . $frTicket['id'] . ' <span style="color: red;">failed</span>' . $nl;
                file_put_contents(__DIR__ . '/src/var/log/failed_tictet_ids.log', print_r($frTicket['id']) . PHP_EOL, FILE_APPEND);
            }

            $messages = $frTicket['notes'];

            // If ticket does not have notes we add a customer message that is in the freshdesk ticket description

            // If ticket contains notes we add the notes as messages
            if (empty($messages) || count($messages) == 1 && strpos($messages[0]['body'], 'user_agent:') === 0) {
                $descriptionMessage = $obj->create('Mirasvit\Helpdesk\Model\Message');
                $descriptionMessage->setData('triggered_by', 'customer');
                $descriptionMessage->setData('customer_email', $frTicket['requester']['email']);
                $descriptionMessage->setData('body', $frTicket['description']);
                $descriptionMessage->setData('created_at', $frTicket['created_at']);
                $descriptionMessage->setData('updated_at', $frTicket['updated_at']);
                $descriptionMessage->setData('type', 'public');
                $descriptionMessage->setData('ticket_id', $ticket->getData('ticket_id'));
                $descriptionMessage->setIsMigration(true);
                $descriptionMessage->save();
                echo ' - a description message is added' . $nl;
            } else {
                for ($j = 0; $j < count($messages); $j++) {
                    $currentMessage = $messages[$j];
                    $msgData        = $currentMessage;
                    unset($msgData['message_id']);

                    $message = $obj->create('Mirasvit\Helpdesk\Model\Message');
                    if (!$currentMessage['support_email']
                        || $ticket->getData('customer_email') == $currentMessage['support_email']) {
                        $message->setData('triggered_by', 'customer');
                        $message->setData('customer_email', $frTicket['requester']['email']);
                        $message->setData('customer_name', $frTicket['requester']['name']);
                        if ($ticket->getData('customer_id')) {
                            $message->setData('triggered_by', 'customer');
                        }
                    } else {
                        $message->setData('triggered_by', 'user');
                    }
                    $message->setData('ticket_id', $ticket->getData('ticket_id'));
                    $message->setData('body', $currentMessage['body']);
                    $message->setData('type', 'public');
                    $message->setData('created_at', $currentMessage['created_at']);
                    $message->setData('updated_at', $currentMessage['updated_at']);

                    $message->setIsMigration(true);
                    $message->save();

                }
                echo ' - ' . count($messages) . ' message(s) added' . $nl;
            }
        }

        // Stage 2: Touch uploaded data - created_at and updated_at fields

        echo $nl . "Mission accomplished" . $nl;

    } catch (Exception $e) {
        echo $e->getMessage() . $nl . $fileToImport;
    }
    $config->saveConfig(
        'helpdesk/developer/is_active',
        $sandboxMode,
        \Magento\Framework\App\Config\ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
        \Magento\Store\Model\Store::DEFAULT_STORE_ID
    );
}

die;
