<?php

require_once('app/Mage.php');

umask(0);

Mage::app();
Varien_Profiler::enable();
Mage::setIsDeveloperMode(true);
ini_set('display_errors', 1);

error_reporting(E_ALL);
ini_set('error_reporting', E_ALL);
ini_set('max_execution_time', 360000);
set_time_limit(360000);

$exportFileName = 'kb_export.xml';

/**
 * Helper function to convert object to XML Node
 *
 * @param Varien_Object $object
 * @param string $tagName
 * @param array $jsonEncoded
 * @return Varien_Simplexml_Element
 */
// @codingStandardsIgnoreStart
function objectToXML($object, $tagName, $jsonEncoded = [])
{
    $dicXML = new Varien_Simplexml_Element('<' . $tagName . '></' . $tagName . '>');
    $attributes = array_keys($object->getData());
    foreach ($attributes as $attribute) {
        if (!in_array($attribute, $jsonEncoded)) {
            $dicXML->addChild($attribute, $object->getData($attribute));
        } else {
            $dicXML->addChild($attribute, base64_encode($object->getData($attribute)));
        }
    }
    return $dicXML;
}
// @codingStandardsIgnoreEnd

echo '<h1>Exporting tool from Knowledge Base to XML</h1><pre>';

$kbXML = new Varien_Simplexml_Element('<KB></KB>');

$dictionaries = new Varien_Simplexml_Element('<Dictionaries></Dictionaries>');
echo 'Exporting dictionaries: <br>';

// 0.1. Categories
$dicCategories = new Varien_Simplexml_Element('<Categories></Categories>');
$categories = Mage::getModel('kb/category')->getCollection();
echo '- Category...';
$jsonData = array('name', 'meta_title', 'meta_keywords', 'meta_description', 'overview');
foreach ($categories as $category) {
    $dicCategories->appendChild(objectToXML($category, 'Category', $jsonData));
}
$dictionaries->appendChild($dicCategories);
echo count($categories) . ' record(s) exported<br>';

// 0.2. Articles
$dicArticles = new Varien_Simplexml_Element('<Articles></Articles>');
$articles = Mage::getModel('kb/article')->getCollection();
echo '- Articles...';
$jsonData = array('name', 'meta_title', 'meta_keywords', 'meta_description', 'text');
foreach ($articles as $article) {
    $dicArticles->appendChild(objectToXML($article, 'Article', $jsonData));
}
$dictionaries->appendChild($dicArticles);
echo count($articles) . ' record(s) exported<br>';

$kbXML->appendChild($dictionaries);

$contents = $kbXML->asNiceXml();

file_put_contents($exportFileName, $contents);

echo '<br>Export complete';

die;