<?php

require_once('app/Mage.php');

umask(0);

Mage::app();
Varien_Profiler::enable();
Mage::setIsDeveloperMode(true);
ini_set('display_errors', 1);

error_reporting(E_ALL);
ini_set('error_reporting', E_ALL);
ini_set('max_execution_time', 360000);
set_time_limit(360000);

$exportFileName = 'helpdesk_export.xml';


/**
 * Helper function to convert object to XML Node
 *
 * @param Varien_Object $object
 * @param string $tagName
 * @param array $jsonEncoded
 * @return Varien_Simplexml_Element
 */
// @codingStandardsIgnoreStart
function objectToXML($object, $tagName, $jsonEncoded = [])
{
    $dicXML = new Varien_Simplexml_Element('<' . $tagName . '></' . $tagName . '>');
    $attributes = array_keys($object->getData());
    foreach ($attributes as $attribute) {
        if (!in_array($attribute, $jsonEncoded)) {
            $dicXML->addChild($attribute, htmlspecialchars($object->getData($attribute)));
        } else {
            $dicXML->addChild($attribute, base64_encode($object->getData($attribute)));
        }
    }
    return $dicXML;
}

function getStoreCodes($model)
{
    $storeCodes = array();
    foreach ((array)$model->getStoreIds() as $storeId) {
        $storeCodes[] = Mage::app()->getStore($storeId)->getCode();
    }
    $data = base64_encode(json_encode($storeCodes));

    return $data;
}
// @codingStandardsIgnoreEnd

echo '<h1>Exporting tool from Help Desk MX to XML</h1><pre>';

$hdXML = new Varien_Simplexml_Element('<HDMX></HDMX>');

// Stage 0: Export dictionaries

$dictionaries = new Varien_Simplexml_Element('<Dictionaries></Dictionaries>');
echo 'Exporting dictionaries: <br>';

// 0.1. Departments
$dicDepartments = new Varien_Simplexml_Element('<Departments></Departments>');
$departments = Mage::getModel('helpdesk/department')->getCollection();
echo '- Departments...';
foreach ($departments as $dept) {
    /** @var Mirasvit_Helpdesk_Model_Department $dept */
    $dept = Mage::getModel('helpdesk/department')->load($dept->getId());
    $userNames = array();
    foreach ((array)$dept->getUserIds() as $userId) {
        $user = Mage::getModel('admin/user')->load($userId);
        $userNames[] = $user->getUserName();
    }
    $data = base64_encode(json_encode($userNames));
    $dept->setUserNames($data);

    $dept->setStoreCodes(getStoreCodes($dept));

    $dept->unsetData('user_ids');
    $dept->unsetData('store_ids');

    $dicDepartments->appendChild(objectToXML($dept, 'Department'));
}
$dictionaries->appendChild($dicDepartments);
echo count($departments) . ' record(s) exported<br>';

// 0.2. Gateways
$dicGateways = new Varien_Simplexml_Element('<Gateways></Gateways>');
$gateways = Mage::getModel('helpdesk/gateway')->getCollection();
echo '- Gateways...';
foreach ($gateways as $gate) {
    $dicGateways->appendChild(objectToXML($gate, 'Gateway'));
}
$dictionaries->appendChild($dicGateways);
echo count($gateways) . ' record(s) exported<br>';

// 0.3. Statuses
$dicStatuses = new Varien_Simplexml_Element('<Statuses></Statuses>');
$statuses = Mage::getModel('helpdesk/status')->getCollection();
echo '- Statuses...';
foreach ($statuses as $status) {
    /** @var Mirasvit_Helpdesk_Model_Status $status */
    $status = Mage::getModel('helpdesk/status')->load($status->getId());

    $status->setStoreCodes(getStoreCodes($status));

    $status->unsetData('store_ids');

    $dicStatuses->appendChild(objectToXML($status, 'Status'));
}
$dictionaries->appendChild($dicStatuses);
echo count($statuses) . ' record(s) exported<br>';

// 0.4. Priorities
$dicPriorities = new Varien_Simplexml_Element('<Priorities></Priorities>');
$priorities = Mage::getModel('helpdesk/priority')->getCollection();
echo '- Priorities...';
foreach ($priorities as $priority) {
    /** @var Mirasvit_Helpdesk_Model_Priority $priority */
    $priority = Mage::getModel('helpdesk/priority')->load($priority->getId());

    $priority->setStoreCodes(getStoreCodes($priority));

    $priority->unsetData('store_ids');

    $dicPriorities->appendChild(objectToXML($priority, 'Priority'));
}
$dictionaries->appendChild($dicPriorities);
echo count($priorities) . ' record(s) exported<br>';

// 0.5. Quick Responses
$dicTemplate = new Varien_Simplexml_Element('<Responses></Responses>');
$templates = Mage::getModel('helpdesk/template')->getCollection();
echo '- Quick Responses...';
foreach ($templates as $template) {
    /** @var Mirasvit_Helpdesk_Model_Template $template */
    $template = Mage::getModel('helpdesk/template')->load($template->getId());

    $template->setStoreCodes(getStoreCodes($template));

    $template->unsetData('store_ids');

    $dicTemplate->appendChild(objectToXML($template, 'Response'));
}
$dictionaries->appendChild($dicTemplate);
echo count($templates) . ' record(s) exported<br>';

// 0.6. Third Party Emails
$skip = true;
try {
    Mage::getModel('helpdesk/thirdPartyEmail');
} catch (\Exception $e) {
    $skip = false;
}
if ($skip) {
    $dicEmails = new Varien_Simplexml_Element('<ThirdPartyEmails></ThirdPartyEmails>');
    $emails = Mage::getModel('helpdesk/thirdPartyEmail')->getCollection();
    echo '- Third Party Emails...';
    foreach ($emails as $email) {
        /** @var Mirasvit_Helpdesk_Model_ThirdPartyEmail $email */
        $email = Mage::getModel('helpdesk/thirdPartyEmail')->load($email->getId());

        $email->setStoreCodes(getStoreCodes($email));

        $email->unsetData('store_ids');

        $dicEmails->appendChild(objectToXML($email, 'Email'));
    }
    $dictionaries->appendChild($dicEmails);
    echo count($emails) . ' record(s) exported<br>';
}

// 0.7. Custom Fields
$dicFields = new Varien_Simplexml_Element('<Fields></Fields>');
$fields = Mage::getModel('helpdesk/field')->getCollection();
echo '- Custom Fields...';
foreach ($fields as $field) {
    /** @var Mirasvit_Helpdesk_Model_Field $field */
    $field = Mage::getModel('helpdesk/field')->load($field->getId());

    $field->setStoreCodes(getStoreCodes($field));

    $field->unsetData('store_ids');

    $dicFields->appendChild(objectToXML($field, 'Field'));
}
$dictionaries->appendChild($dicFields);
echo count($fields) . ' record(s) exported<br>';

// 0.8. Spam Patterns
$dicPatterns = new Varien_Simplexml_Element('<SpamPatterns></SpamPatterns>');
$patterns = Mage::getModel('helpdesk/pattern')->getCollection();
echo '- Spam Patterns...';
foreach ($patterns as $pattern) {
    $dicPatterns->appendChild(objectToXML($pattern, 'Pattern'));
}
$dictionaries->appendChild($dicPatterns);
echo count($patterns) . ' record(s) exported<br>';

// 0.8. Permissions
$dicPermissions = new Varien_Simplexml_Element('<Permissions></Permissions>');
$permissions = Mage::getModel('helpdesk/permission')->getCollection();
echo '- Permissions...';
foreach ($permissions as $permission) {
    $dicPermissions->appendChild(objectToXML($permission, 'Permission'));
}
$dictionaries->appendChild($dicPermissions);
echo count($permissions) . ' record(s) exported<br>';

$hdXML->appendChild($dictionaries);

// Stage 1: Export tickets with messages
echo '<br>Exporting tickets: <br>';
$ticketXML = new Varien_Simplexml_Element('<Tickets></Tickets>');
$tickets = Mage::getModel('helpdesk/ticket')->getCollection();
foreach ($tickets as $ticket) {
    // @codingStandardsIgnoreStart
    $ticketData = objectToXML($ticket, 'Ticket', array('name', 'customer_name', 'last_reply_name', 'f_company'));
    // @codingStandardsIgnoreEnd
    echo '- ticket #' . $ticket->getCode() . '...';

    $messages = Mage::getModel('helpdesk/message')->getCollection()
        ->addFieldToFilter('ticket_id', $ticket->getId());
    $msgXML = new Varien_Simplexml_Element('<Messages></Messages>');
    foreach ($messages as $message) {
        // @codingStandardsIgnoreStart
        $msgXML->appendChild(objectToXML($message, 'Message', array('body', 'customer_name')));
        // @codingStandardsIgnoreEnd
    }
    echo count($messages) . ' message(s) exported<br>';
    $ticketData->appendChild($msgXML);
    $ticketXML->appendChild($ticketData);
}
$hdXML->appendChild($ticketXML);

$contents = $hdXML->asNiceXml();

file_put_contents($exportFileName, $contents);

echo '<br>Export complete';

die;
